---
name: Ref Ready
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#43474e'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#74777f'
  outline-variant: '#c4c6cf'
  surface-tint: '#455f88'
  primary: '#002045'
  on-primary: '#ffffff'
  primary-container: '#1a365d'
  on-primary-container: '#86a0cd'
  inverse-primary: '#adc7f7'
  secondary: '#a04100'
  on-secondary: '#ffffff'
  secondary-container: '#fe6b00'
  on-secondary-container: '#572000'
  tertiary: '#00270c'
  on-tertiary: '#ffffff'
  tertiary-container: '#003f18'
  on-tertiary-container: '#00b753'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#adc7f7'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#2d476f'
  secondary-fixed: '#ffdbcc'
  secondary-fixed-dim: '#ffb693'
  on-secondary-fixed: '#351000'
  on-secondary-fixed-variant: '#7a3000'
  tertiary-fixed: '#6bff8f'
  tertiary-fixed-dim: '#4ae176'
  on-tertiary-fixed: '#002109'
  on-tertiary-fixed-variant: '#005321'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Anybody
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Anybody
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Anybody
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-md:
    fontFamily: Anybody
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-bold:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  button:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 20px
  container-max: 1280px
---

## Brand & Style

The design system is engineered for a high-trust, professional sports-tech environment. It balances the authoritative reliability of officiating with the high-energy excitement of athletic competition. The aesthetic is **Corporate Modern** with a **Tactile** edge—utilizing clean lines, intentional whitespace, and subtle depth to evoke the premium feel of a digital financial instrument or high-end gift card registry.

The target audience includes sports officials, league administrators, and corporate partners. The UI should feel secure and structured, yet move with the kinetic energy of the sporting world. Visuals are grounded in precision, using bold typography to signal confidence and soft elevation to provide a sense of physical tangibility.

## Colors

The palette is anchored by **Ref Blue** (#1A365D), a deep navy-royal hybrid that establishes immediate professional authority and trust. This is contrasted by **Action Orange** (#FF6B00), a high-vibrancy accent reserved for critical calls-to-action and momentum-building interactions.

**Success Green** (#22C55E) is utilized strictly for verification states, completed transactions, and positive status indicators. The neutral scale relies on cool slates and grays to maintain a clean, "tech-forward" atmosphere without feeling sterile. Use the background hex for large canvas areas to allow white surface cards to pop with clarity.

## Typography

This design system utilizes **Anybody** for headlines to capture an aggressive, athletic spirit. Its variable widths and bold weights provide the "game-day" impact required for a sports-tech product. For body copy and functional data, **Hanken Grotesk** offers a sharp, contemporary professional feel that ensures legibility during high-stakes financial interactions.

Headlines should use tight tracking and bold weights to command attention. Labels and metadata should lean into the medium and bold weights of Hanken Grotesk, often utilizing subtle uppercase styling for section headers to maintain a disciplined, organized hierarchy.

## Layout & Spacing

The layout follows a **fluid grid** logic with a 12-column structure for desktop and a 4-column structure for mobile. A base unit of 8px dictates all spatial relationships, ensuring a mathematical rigor that reflects the precision of officiating.

On mobile, margins are set to 20px to provide breathing room for thumb-driven interactions. Desktop layouts prioritize a centered container with a maximum width of 1280px to prevent line lengths from becoming unreadable on ultra-wide monitors. Content reflow should prioritize vertical stacking for complex data tables when transitioning to smaller breakpoints.

## Elevation & Depth

Depth is achieved through **ambient shadows** and **tonal layering**. This design system avoids harsh blacks; instead, shadows are tinted with the Ref Blue primary color at very low opacities (8-12%) to keep the interface feeling "airy" and premium.

- **Level 0 (Floor):** The base background color.
- **Level 1 (Cards):** White surfaces with a soft 4px blur shadow. Used for standard content sections.
- **Level 2 (Interactive):** Elements like "Action" buttons or active gift cards use an 8px blur shadow to suggest they sit higher and are ready to be "picked up."
- **Level 3 (Modals):** Large 24px blur shadows for high-priority overlays to push everything else into the background.

## Shapes

The shape language is defined as **Rounded**, utilizing a 0.5rem (8px) base radius. This softens the intensity of the bold typography, making the "premium digital gift card" experience feel approachable and modern.

Buttons and input fields share this 8px radius to maintain a cohesive container language. For specialized components like status "Chips" or "Pills," the rounded-xl (1.5rem) setting should be applied to create a distinct visual contrast from the primary structural cards.

## Components

### Buttons
- **Primary:** Action Orange background, white text. Bold, sans-serif typography. Uses Level 2 elevation on hover.
- **Secondary:** Ref Blue background or 2px Ref Blue border. Professional and sturdy.
- **Ghost:** No background, Ref Blue text. Used for secondary navigation or "Cancel" actions.

### Cards & Registries
Cards should feel like physical objects. Use a white surface, 8px corner radius, and Level 1 elevation. When displaying "Gift Cards," use a subtle gradient overlay of Ref Blue to give the component a premium, holographic-adjacent depth.

### Input Fields
Inputs use a 1px slate-300 border that thickens to 2px Ref Blue on focus. Use Hanken Grotesk for typed text to ensure maximum clarity for numeric financial data.

### Chips & Badges
Small, pill-shaped indicators for "Verified," "Pending," or "New." Use Success Green with 10% opacity background and 100% opacity text for a modern, accessible status look.

### Progress Bars
Utilize the 8px roundedness for the track and the bar. The track should be a light gray-100, while the progress indicator should be Ref Blue or Action Orange depending on the urgency of the task.